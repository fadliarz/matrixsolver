// Responsive table method using display:block and data attributes
// Thanks to @leefroese for suggestion about data attributes